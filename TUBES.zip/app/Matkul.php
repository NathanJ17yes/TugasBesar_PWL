<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Matkul extends Model
{
    protected $table = 'mata_kuliah';

    protected $primaryKey = 'kode_matkul';
    protected $fillable = [
        'kode_matkul',
        'nama_matkul',
        'semester',
        'kode_prodi'

    ];
}
